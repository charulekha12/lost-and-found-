Lost & Found app - local secrets bundle
========================================

These files were removed from git tracking (and purged from git history)
because they contain real Firebase project credentials. Share this zip
with teammates out-of-band (Drive, Keeper, etc.) - never via git.

Put each file back at this path in your local clone:

  google-services.json   -> android/app/google-services.json
  firebase_options.dart  -> lib/firebase_options.dart
  local.properties       -> android/local.properties  (or let Android
                             Studio/Flutter regenerate it automatically -
                             it just needs to point at your local Flutter SDK)

After copying them in, `flutter pub get` + `flutter run` should work as before.
